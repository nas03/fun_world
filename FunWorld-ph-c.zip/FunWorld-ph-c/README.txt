cd src
npm install --save three
npm install --save-dev vite
npx vite